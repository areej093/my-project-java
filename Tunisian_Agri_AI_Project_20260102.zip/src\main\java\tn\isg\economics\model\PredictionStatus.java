package tn.isg.economics.model;

public enum PredictionStatus {
    PENDING, COMPLETED, FAILED, LOW_CONFIDENCE
}
