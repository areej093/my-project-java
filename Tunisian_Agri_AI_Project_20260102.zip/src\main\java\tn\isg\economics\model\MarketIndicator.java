package tn.isg.economics.model;

public enum MarketIndicator {
    STABLE, VOLATILE, RISING, FALLING, UNPREDICTABLE
}
